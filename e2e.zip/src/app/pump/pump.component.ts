import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pump',
  templateUrl: './pump.component.html',
  styleUrls: ['./pump.component.css']
})
export class PumpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
