import { Component, OnInit } from '@angular/core';
import { DataSharingService } from '../data-sharing.service';


@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent implements OnInit {
  formData: any;

  constructor(private dataSharingService: DataSharingService) { }

  ngOnInit(): void {
    this.formData = this.dataSharingService.getData();
    console.log(this.formData);
    
  }
  

}
