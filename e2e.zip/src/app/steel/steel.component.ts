import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-steel',
  templateUrl: './steel.component.html',
  styleUrls: ['./steel.component.css']
})
export class SteelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
