import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataSharingService {
  private formData: any;

  constructor() { }

  setData(data: any) {
    this.formData = data;
  }

  getData() {
    return this.formData;
  }
}
