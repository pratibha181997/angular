import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sand',
  templateUrl: './sand.component.html',
  styleUrls: ['./sand.component.css']
})
export class SandComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
